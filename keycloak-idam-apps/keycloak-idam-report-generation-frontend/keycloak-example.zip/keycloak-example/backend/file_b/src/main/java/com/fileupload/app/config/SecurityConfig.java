package com.fileupload.app.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Value("${spring.security.oauth2.resourceserver.jwt.jwk-set-uri}")
    private String jwkSetUri;

    @Value("${app.frontend-url}")
    private String frontendUrl;
    
    @Value("${app.landing-page-url}")
    private String landingPageUrl;
 
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/public/**", "/actuator/**", "/error", "/login/**", "/oauth2/**").permitAll()
                .anyRequest().authenticated()
            )
            .oauth2Login(oauth2 -> oauth2
                .userInfoEndpoint(userInfo -> userInfo.oidcUserService(oidcUserService()))
                // Use custom success handler for role-based redirection
                .successHandler(roleBasedAuthenticationSuccessHandler())
                .failureUrl("/login?error")
            )
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.jwtAuthenticationConverter(jwtAuthenticationConverter()))
            )
            .logout(logout -> logout
                .logoutSuccessUrl(landingPageUrl)
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .deleteCookies("JSESSIONID")
            );
        
        return http.build();
    }

    @Bean
    public AuthenticationSuccessHandler roleBasedAuthenticationSuccessHandler() {
        return new AuthenticationSuccessHandler() {
            @Override
            public void onAuthenticationSuccess(HttpServletRequest request, 
                                              HttpServletResponse response,
                                              Authentication authentication) 
                    throws IOException, ServletException {
                
                Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
                
                System.out.println("=== Role-Based Redirect Logic ===");
                System.out.println("User: " + authentication.getName());
                log.info("roleBasedAuthenticationSuccessHandler()::: User: {}",authentication.getName());
                System.out.println("Authorities: " + authorities);
                log.info("roleBasedAuthenticationSuccessHandler()::: Roles: {}",authorities);
                String redirectUrl = determineRedirectUrl(authorities);
                
                System.out.println("Redirecting to: " + redirectUrl);
                System.out.println("================================");
                
                response.sendRedirect(redirectUrl);
            }
            
            private String determineRedirectUrl(Collection<? extends GrantedAuthority> authorities) {
                // Check for admin role first (highest priority)
                if (hasRole(authorities, "ROLE_admin") || hasRole(authorities, "ROLE_ADMIN")
                		|| hasRole(authorities, "ENIQ_Administrator")|| hasRole(authorities, "ROLE_ENIQ_Administrator")||
                		hasRole(authorities, "eniq_administrator")|| hasRole(authorities, "ROLE_eniq_administrator")) {
                	log.info("determineRedirectUrl()::: Roles: {}",authorities);
                    System.out.println("Admin detected - redirecting to landing page");
                    return landingPageUrl; // Admins go to landing page (port 3000)
                }
                
                // Check for report user role
                if (hasRole(authorities, "ROLE_report_user") || 
                    hasRole(authorities, "netan_ui") ||
                    hasRole(authorities, "report_user") ||
                    hasRole(authorities, "ROLE_netan_ui")) { 
                    System.out.println("netan user detected - redirecting to report app");
                    log.info("determineRedirectUrl()::: Roles: {}",authorities);
                    return "http://localhost:3001"; // Report app frontend
                }
                
                // Check for file upload user role
                if (hasRole(authorities, "ROLE_file_user") || 
                    hasRole(authorities, "eniqadmin_ui") ||
                    hasRole(authorities, "file_user") ||
                    hasRole(authorities, "ROLE_eniqadmin_ui")) { 
                    System.out.println("File user detected - redirecting to file upload app");
                    log.info("determineRedirectUrl()::: Roles: {}",authorities);
                    return "http://localhost:3002"; // File upload app frontend
                }
                
                // Default: redirect to landing page
                System.out.println("No specific role found - redirecting to landing page");
                return landingPageUrl;
            }
            
            private boolean hasRole(Collection<? extends GrantedAuthority> authorities, String role) {
                return authorities.stream()
                    .anyMatch(auth -> auth.getAuthority().equalsIgnoreCase(role));
            }
        };
    }

    @Bean
    public OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService() {
        final OidcUserService delegate = new OidcUserService();

        return userRequest -> {
            try {
                OidcUser oidcUser = delegate.loadUser(userRequest);
                
                Set<GrantedAuthority> authorities = new HashSet<>();
                extractRolesFromClaims(oidcUser.getClaims(), authorities);
                
                if (authorities.isEmpty()) {
                    authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                }
                
                System.out.println("DEBUG: User " + oidcUser.getPreferredUsername() + 
                                 " authenticated with authorities: " + authorities);
                
                return new DefaultOidcUser(authorities, oidcUser.getIdToken(), oidcUser.getUserInfo());
            } catch (Exception e) {
                System.err.println("ERROR: Failed to load user - " + e.getMessage());
                e.printStackTrace();
                throw e;
            }
        };
    }

    private void extractRolesFromClaims(Map<String, Object> claims, Set<GrantedAuthority> authorities) {
        try {
            System.out.println("DEBUG: Available claims: " + claims.keySet());
            
            // Extract from realm_access
            Object realmAccessObj = claims.get("realm_access");
            if (realmAccessObj instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> realmAccess = (Map<String, Object>) realmAccessObj;
                Object rolesObj = realmAccess.get("roles");
                
                if (rolesObj instanceof List) {
                    @SuppressWarnings("unchecked")
                    List<String> roles = (List<String>) rolesObj;
                    System.out.println("DEBUG: Found realm_access roles: " + roles);
                    
                    roles.stream()
                        .filter(role -> !role.startsWith("default-") && 
                                      !role.startsWith("offline_") && 
                                      !role.startsWith("uma_"))
                        .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                        .forEach(authorities::add);
                }
            }
            
            System.out.println("DEBUG: Final extracted authorities: " + authorities);
        } catch (Exception e) {
            System.err.println("ERROR: Failed to extract roles - " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Bean
    public JwtDecoder jwtDecoder() {
        return NimbusJwtDecoder.withJwkSetUri(jwkSetUri).build();
    }

    private JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        
        converter.setJwtGrantedAuthoritiesConverter(jwt -> {
            Set<GrantedAuthority> authorities = new HashSet<>();
            
            try {
                Map<String, Object> realmAccess = jwt.getClaim("realm_access");
                if (realmAccess != null && realmAccess.get("roles") != null) {
                    @SuppressWarnings("unchecked")
                    List<String> roles = (List<String>) realmAccess.get("roles");
                    
                    roles.stream()
                        .filter(role -> !role.startsWith("default-") && 
                                      !role.startsWith("offline_") && 
                                      !role.startsWith("uma_"))
                        .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                        .forEach(authorities::add);
                }
                
                if (authorities.isEmpty()) {
                    authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                }
            } catch (Exception e) {
                System.err.println("ERROR: Failed to convert JWT authorities - " + e.getMessage());
                authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
            }
            
            return new ArrayList<>(authorities);
        });
        
        return converter;
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList(
            "http://localhost:3000",
            "http://localhost:3001",
            "http://localhost:3002"
        ));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}